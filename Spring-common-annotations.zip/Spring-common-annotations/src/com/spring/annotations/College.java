package com.spring.annotations;

import org.springframework.stereotype.Component;

//@Component("collegeBean")
public class College {
	
	private Principal principal;
	private Teacher teacher;
	
 
	/*
	 * public College(Principal principalBean) { // TODO Auto-generated constructor
	 * stub }
	 */

		public Teacher getTeacher() {
		return teacher;
	}


	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}


		public void display() {
			principal.principalInfo();
			teacher.teach();
		System.out.println("this is a testing class");
	}


		public Principal getPrincipal() {
			return principal;
		}


		public void setPrincipal(Principal principal) {
			this.principal = principal;
		}
}
