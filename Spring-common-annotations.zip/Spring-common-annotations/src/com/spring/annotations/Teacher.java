package com.spring.annotations;

public interface Teacher {
    public void teach();
}
