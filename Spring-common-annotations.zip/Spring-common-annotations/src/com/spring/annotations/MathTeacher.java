package com.spring.annotations;

public class MathTeacher implements Teacher{

	@Override
	public void teach() {
		// TODO Auto-generated method stub
		System.out.println("Hi iam a math teacher");
		System.out.println("My name is pandith");
	}

}
