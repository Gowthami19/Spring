package com.spring.annotations;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
//@ComponentScan(basePackages = "com.spring.annotations")
public class CollegeConfig {

	// @Bean(name="collegeBean") we can give single name
	// @Bean(name= {"colbean","collegeBean"}) We can give Multiple names
	
	
	@Bean
	public Teacher mathTeacherBean() {
		System.out.println("MathTeacherBean");
		return new MathTeacher();
	}
	
	@Bean
	public Principal principalBean() {
		Principal princ=new Principal();
		System.out.println("Principal Bean");
		return princ;
	}
	
	@Bean
	public College collegeBean() {    //collegebean/id
		College bean = new College();
		bean.setPrincipal(principalBean());
		bean.setTeacher(mathTeacherBean());
		System.out.println("College Bean");
		return bean;
	}
	
	
	
}
