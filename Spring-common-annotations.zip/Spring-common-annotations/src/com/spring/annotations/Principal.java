package com.spring.annotations;

public class Principal {

	public void principalInfo() {
		System.out.println("Iam the principal");
		System.out.println("My name is JamsBond");
	}
}
