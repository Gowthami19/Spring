package com.spring.di;

public class Student {

	private String StudentName;
	private int Rollno;
	private Address address;

	public void setRollno(int rollno) {
		Rollno = rollno;
	}

	public void setStudentName(String studentName) {
		StudentName = studentName;
		
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public void displayInfo() {
		System.out.println("StudentName: " + StudentName);
		System.out.println("StudentRollNo: "+Rollno);
		System.out.println("StudentAddress: "+address);
	}
	
}

