package com.spring.di;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Exam {

	public static void main(String[] args) {
        
		 ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		 Student stud=(Student) context.getBean("student");
		 stud.displayInfo();
		
	}
	
}
