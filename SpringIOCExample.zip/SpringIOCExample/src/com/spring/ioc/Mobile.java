package com.spring.ioc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Mobile {

	public static void main(String[] args) {
          ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
          System.out.println("Spring xml is loaded");
          Airtel air=(Airtel) context.getBean("airtel");   //for the airtel class
          air.calling();
          air.data();
          
          Vodafone voda=(Vodafone) context.getBean("vodafone");   //for the vodafone class
          voda.calling();
          voda.data();
          
          Sim sim=(Sim) context.getBean("sim",Sim.class);  
          sim.calling();
          sim.data();
          
	}

}
