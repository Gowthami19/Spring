package com.spring.ioc;

public interface Sim {
      void calling();
      void data();
}
