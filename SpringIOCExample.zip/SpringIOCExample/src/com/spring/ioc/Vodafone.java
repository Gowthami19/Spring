package com.spring.ioc;

public class Vodafone implements Sim {

	@Override
	public void calling() {
		System.out.println("Calling the vodafone sim");
	}

	@Override
	public void data() {
		System.out.println("Data using through the vodafone");
	}

}
