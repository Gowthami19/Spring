package com.spring.autowired;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Human {
	
	private Heart heart;

	public Human() {

	}

	public Human(Heart heart) {
		super();
		this.heart = heart;
	}

	public Heart getHeart() {
		return heart;
	}
	@Autowired
    @Qualifier("heartObj")
	public void setHeart(Heart heart) {
		this.heart = heart;
		System.out.println("Setter method is called");
	}

	public void heart() {
		if (heart != null) {
			heart.pump();
		} else {
			System.out.println("Your dead");
		}
	}
}
