package com.spring.applicationproperties;

import org.springframework.beans.factory.annotation.Value;

public class Student {
	
	  @Value("${student.name}") 
   private String name;
   private String course;
   private String hobby;
   
public String getName() {
	return name;
}

   //@Value("gowthami")
   //@Value("${student.name}") 
//   @Required
  public void setName(String name) {
	this.name = name;
}
public String getCourse() {
	return course;
}
@Value("${student.course}") 

public void setCourse(String course) {
	this.course = course;
}
public String getHobby() {
	return hobby;
}
@Value("${student.hobby}") 

public void setHobby(String hobby) {
	this.hobby = hobby;
}
   public void displayStudentInfo() {
	   System.out.println("StudentName: "+name);
	   System.out.println("StudentCourse: "+course);
	   System.out.println("StudentHobby: "+hobby);

   }
}
