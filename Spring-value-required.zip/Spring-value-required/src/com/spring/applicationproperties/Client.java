package com.spring.applicationproperties;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {

		ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		System.out.println("Container is loaded");
		Student stud=(Student) context.getBean("student");
		System.out.println("Student Object");
		stud.displayStudentInfo();
	}

}
